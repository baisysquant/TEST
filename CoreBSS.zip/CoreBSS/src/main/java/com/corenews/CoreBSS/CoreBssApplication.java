package com.corenews.CoreBSS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreBssApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreBssApplication.class, args);
	}

}
