package com.corenews.CoreBSS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreBssApplicationTests {

	@Test
	void contextLoads() {
	}

}
